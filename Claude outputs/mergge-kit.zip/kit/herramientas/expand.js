// node expand.js in.dc.html out.dc.html '{"sel":2}'
const fs=require('fs');
const [,,inp,out,st]=process.argv;
const raw=fs.readFileSync(inp,'utf8');
const sm=raw.match(/<script type="text\/x-dc"[^>]*>([\s\S]*?)<\/script>/);
let vals={};
if(sm){
  class DCLogic{constructor(p){this.props=p||{};this.state={};}setState(s){Object.assign(this.state,s);}}
  const C=new Function('DCLogic',sm[1]+'\nreturn Component;')(DCLogic);
  const c=new C({}); if(st) Object.assign(c.state,JSON.parse(st)); vals=c.renderVals();
}
const get=(o,k)=>k.split('.').reduce((a,b)=>a==null?a:a[b],o);
const sub=(s,ctx)=>s.replace(/\{\{\s*([\w.]+)\s*\}\}/g,(_,k)=>{const v=get(ctx,k);return typeof v==='function'||v==null?'':String(v);});
let body=raw;
// sc-if
function exp(s,ctx){
  s=s.replace(/<sc-for list="\{\{\s*([\w.]+)\s*\}\}" as="(\w+)"[^>]*>([\s\S]*?)<\/sc-for>/g,(_,l,a,t)=>(get(ctx,l)||[]).map(it=>exp(t,Object.assign({},ctx,{[a]:it}))).join(''));
  s=s.replace(/<sc-if value="\{\{\s*([\w.]+)\s*\}\}"[^>]*>([\s\S]*?)<\/sc-if>/g,(_,k,t)=>get(ctx,k)?t:'');
  return sub(s,ctx);
}
const m=raw.match(/<x-dc>([\s\S]*)<\/x-dc>/);
body=raw.replace(m[1],exp(m[1],vals)).replace(/<script type="text\/x-dc"[\s\S]*?<\/script>/,'<script type="text/x-dc" data-props=\''+(raw.match(/data-props='([^']*)'/)||[,''])[1]+'\'></script>');
fs.writeFileSync(out,body);
