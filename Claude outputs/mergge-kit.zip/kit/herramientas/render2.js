const {chromium}=require('playwright'),fs=require('fs'),path=require('path');
const DIR=process.env.DIR||'/home/claude/sextante/campos/project';
const B64=require('fs').readFileSync(''+__dirname+'/fonts/anton-latin-400-normal.woff2').toString('base64');
const SRC='url(data:font/woff2;base64,'+B64+') format("woff2")';

const PP=[400,500,600,700].map(w=>'@font-face{font-family:"Poppins";font-weight:'+w+';src:url(data:font/woff2;base64,'+require('fs').readFileSync(''+__dirname+'/fonts/poppins-latin-'+w+'-normal.woff2').toString('base64')+') format("woff2");}').join('');
const FONTCSS='<style>'+PP+'@font-face{font-family:"Anton";src:'+SRC+';font-weight:400;font-style:normal;}@font-face{font-family:"Impact";src:'+SRC+';}@font-face{font-family:"Haettenschweiler";src:'+SRC+';}</style>';
(async()=>{
 const b=await chromium.launch();
 for(const f of process.argv.slice(2)){
  const raw=fs.readFileSync(path.join(DIR,f),'utf8');
  const m=raw.match(/<x-dc>([\s\S]*)<\/x-dc>/);
  const hm=raw.match(/<helmet>([\s\S]*?)<\/helmet>/);
  let body=m[1].replace(/<helmet>[\s\S]*?<\/helmet>/,'');
  const wm=raw.match(/"width":(\d+),"height":(\d+)/);
  const W=+wm[1],H=+wm[2];
  const p=await b.newPage({viewport:{width:W,height:Math.min(H,4000)},deviceScaleFactor:1});
  await p.setContent('<!doctype html><html><head><meta charset="utf-8">'+(hm?hm[1]:'')+FONTCSS+'</head><body style="margin:0">'+body+'</body></html>',{waitUntil:'load'});
  await p.waitForTimeout(1200);
  const out=''+__dirname+'/shots/'+f.replace('.dc.html','')+'.png';
  await p.screenshot({path:out,fullPage:true});
  console.log(out,W,H);
  await p.close();
 }
 await b.close();
})();
