import re, json
src=open(__import__('os').path.join(__import__('os').path.dirname(__file__),'..','tableros','Servicios.dc.html')).read()
STAR=re.search(r'<path d="(M 0\.00 -100\.00[^"]+)"',src).group(1)
hs=src.find('<div style="position: absolute; left: 50px; right: 34px; top: 30px;')
he=src.find('</nav></div>',hs)+len('</nav></div>')
HEADER=src[hs:he]+'<div style="position: absolute; left: 0; right: 0; top: 86px; height: 1px; background: rgba(241,238,228,0.3);"></div>'
HEAD=src[:src.find('<div style="width: 1440px')]
C='#F1EEE4'; O='#FF4500'; B='#3130E3'; M='#310D00'
def star(sz,fill,op=1,rot=0,stroke=None,sw=1.6):
    f=f'fill="{fill}"' if not stroke else f'fill="none" stroke="{stroke}" stroke-width="{sw}" vector-effect="non-scaling-stroke"'
    return f'<svg viewBox="-100 -100 200 200" style="width: {sz}px; height: {sz}px; display: block; opacity: {op};" aria-hidden="true"><path d="{STAR}" {f} transform="rotate({rot})"></path></svg>'
def grain(seed,op=0.2):
    return f'<svg style="position: absolute; left: 0; top: 0; width: 100%; height: 100%; opacity: {op}; pointer-events: none; mix-blend-mode: soft-light;" aria-hidden="true"><filter id="gn{seed}"><feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="3" seed="{seed}"></feTurbulence><feColorMatrix type="saturate" values="0"></feColorMatrix></filter><rect width="100%" height="100%" filter="url(#gn{seed})"></rect></svg>'
def nb(t):
    w=t.rsplit(' ',1); return w[0]+' '+w[1] if len(w)==2 else t
QA=[
 ("¿Cuánto cuesta una web?","Depende de lo que necesites. Después de la charla te pasamos un presupuesto cerrado, así sabés desde el principio cuánto vas a pagar."),
 ("¿Cómo se paga?","50 % al empezar y 50 % al entregar. El proceso arranca cuando recibimos el primer pago y la información que necesitamos para empezar."),
 ("¿Cuánto tarda?","Entre 3 y 8 semanas, según lo que incluya tu web. La fecha exacta te la damos en la propuesta."),
 ("¿Qué tengo que tener listo?","Saber qué hace tu negocio y a quién le vende. Si ya tenés logo, textos y fotos, mejor; si te falta algo, lo vemos juntos en la charla."),
 ("¿Voy a poder cambiar cosas yo?","Sí, si lo necesitás. La armamos para que cambies textos y fotos desde un panel simple, y te enseñamos a usarlo."),
 ("¿Trabajan con gente de otras ciudades?","Sí. Somos de Mar del Plata y trabajamos con gente de todo el país. Todo el proceso se hace a distancia."),
 ("¿Usan plantillas o inteligencia artificial?","No. Cada web se diseña y se programa desde cero para tu negocio, y la pensamos los dos juntos desde el primer boceto."),
]
def h(t): return t.replace(' ','&nbsp;')
def js_data():
    return '[\n      '+',\n      '.join(json.dumps([p,nb(r)],ensure_ascii=False) for p,r in QA)+'\n    ]'
def btn(label,bg=O,fg=M,href='#contacto',w=None,border=None):
    ws=f'width: {w}px; ' if w else 'padding: 0 30px; '
    bd=f'border: 1.5px solid {border}; ' if border else ''
    return f'<a href="{href}" style="display: inline-flex; align-items: center; justify-content: center; gap: 10px; height: 56px; {ws}{bd}box-sizing: border-box; flex-shrink: 0; border-radius: 999px; background: {bg}; color: {fg}; font-size: 16px; font-weight: 600; letter-spacing: 0.01em;">{label}<span style="font-size: 18px; line-height: 1;">&#8594;</span></a>'
def page(title,H,bg,inner,logic=None):
    head=HEAD.replace('<title>Mergge — Diseño de marca</title>',f'<title>Mergge — {title}</title>')
    body=f'<div style="width: 1440px; height: {H}px; box-sizing: border-box; background: {bg}; position: relative; overflow: hidden;">{inner}</div>'
    lg=logic or 'class Component extends DCLogic {\n  renderVals() { return {}; }\n}'
    return head+body+'\n</x-dc>\n<script type="text/x-dc" data-dc-script data-props=\'{"$preview":{"width":1440,"height":%d}}\'>\n'%H+lg+'\n</script>\n</body>\n</html>\n'
def title2(size,col,stroke=None,left=48,top=140,gap_one_line=False,sw=2):
    st=stroke or col
    a=f"font-family: 'Anton', sans-serif; font-weight: 400; font-size: {size}px; line-height: 0.96; text-transform: uppercase; white-space: nowrap; margin: 0;"
    if gap_one_line:
        return f'<h2 style="position: absolute; left: {left}px; top: {top}px; {a} color: {col};">Preguntas <span style="color: transparent; -webkit-text-stroke: {sw}px {st};">frecuentes</span></h2>'
    return f'<div style="position: absolute; left: {left}px; top: {top}px;"><h2 style="{a} color: {col};">Preguntas</h2><h2 style="{a} color: transparent; -webkit-text-stroke: {sw}px {st};">Frecuentes</h2></div>'
