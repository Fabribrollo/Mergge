from faqlib import *
def ok(c=B): return f'<svg viewBox="0 0 20 20" style="width: 20px; height: 20px; flex-shrink: 0; display: block;" aria-hidden="true"><circle cx="10" cy="10" r="10" fill="{c}"></circle><path d="M5.6 10.4 L8.6 13.2 L14.4 7.2" fill="none" stroke="{C}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>'
def ko(c=O,stroke=M): return f'<svg viewBox="0 0 20 20" style="width: 20px; height: 20px; flex-shrink: 0; display: block;" aria-hidden="true"><circle cx="10" cy="10" r="10" fill="{c}"></circle><path d="M6.8 6.8 L13.2 13.2 M13.2 6.8 L6.8 13.2" fill="none" stroke="{stroke}" stroke-width="2.2" stroke-linecap="round"></path></svg>'
def chip(t,kind,dark=True):
    st={'bien': (f'rgba(241,238,228,0.16)',C) if dark else ('rgba(49,48,227,0.12)',B),
        'mejorar': (O,M), 'falta': (M,C) if not dark else (C,M)}[kind]
    return f'<span style="display: inline-flex; align-items: center; height: 30px; padding: 0 14px; border-radius: 999px; background: {st[0]}; color: {st[1]}; font-size: 13px; font-weight: 600; letter-spacing: 0.04em; white-space: nowrap;">{t}</span>'
def eyebrow(t,col='rgba(241,238,228,0.86)',bd='rgba(241,238,228,0.3)'):
    return f'<span style="display: inline-flex; align-items: center; gap: 10px; height: 36px; padding: 0 18px; border-radius: 999px; border: 1px solid {bd}; font-size: 13px; font-weight: 600; letter-spacing: 0.12em; text-transform: uppercase; color: {col}; white-space: nowrap;">{star(12,O,1,10)}{t}</span>'
def btn2(label,col=C,bd='rgba(241,238,228,0.6)',arrow='&#8594;'):
    return f'<a href="#" style="display: inline-flex; align-items: center; justify-content: center; gap: 10px; height: 56px; padding: 0 30px; box-sizing: border-box; flex-shrink: 0; border-radius: 999px; background: transparent; color: {col}; font-size: 16px; font-weight: 600; box-shadow: inset 0 0 0 1.5px {bd};">{label}<span style="font-size: 18px; line-height: 1;">{arrow}</span></a>'
def A(t,size,col,stroke=None,extra=''):
    s=f"font-family: 'Anton', sans-serif; font-weight: 400; font-size: {size}px; line-height: 0.92; text-transform: uppercase; white-space: nowrap; margin: 0;"
    if stroke: return f'<div style="{s} color: transparent; -webkit-text-stroke: {stroke}px {col}; {extra}">{t}</div>'
    return f'<div style="{s} color: {col}; {extra}">{t}</div>'
def ring(val,size,track,fill,txt,sub,subcol):
    r=size/2-12; import math; L=2*math.pi*r; d=L*val/100
    return f'<div style="position: relative; width: {size}px; height: {size}px;"><svg viewBox="0 0 {size} {size}" style="width: {size}px; height: {size}px; display: block; transform: rotate(-90deg);" aria-hidden="true"><circle cx="{size/2}" cy="{size/2}" r="{r:.1f}" fill="none" stroke="{track}" stroke-width="14"></circle><circle cx="{size/2}" cy="{size/2}" r="{r:.1f}" fill="none" stroke="{fill}" stroke-width="14" stroke-linecap="round" stroke-dasharray="{d:.1f} {L:.1f}"></circle></svg><div style="position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center;"><span style="font-family: \'Anton\', sans-serif; font-size: {int(size*0.36)}px; line-height: 1; color: {txt};">{val}</span><span style="margin-top: 4px; font-size: {12 if size<180 else 14}px; font-weight: 600; letter-spacing: 0.1em; text-transform: uppercase; color: {subcol};">{sub}</span></div></div>'
BG_BLUE=f'radial-gradient(circle 760px at 100% 100%, rgba(255,69,0,0.42) 0%, rgba(255,69,0,0) 70%), radial-gradient(circle 680px at 0% 0%, rgba(120,118,255,0.5) 0%, rgba(120,118,255,0) 70%), radial-gradient(circle 520px at 38% 72%, rgba(20,18,140,0.55) 0%, rgba(20,18,140,0) 70%), {B}'
